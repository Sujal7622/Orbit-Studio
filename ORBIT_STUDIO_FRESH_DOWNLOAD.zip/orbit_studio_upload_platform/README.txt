ORBIT STUDIO — REAL VIDEO UPLOAD WEBSITE
=========================================

WHAT THIS VERSION DOES
- Serves the Orbit Studio website using Flask.
- Client enters their details and can optionally attach up to 10 reference files.
- Browser shows upload progress.
- Server checks file extensions and supports video, images, PDFs, office documents, audio, archives and design references. Maximum 200 MB per file; up to 10 files.
- Uploaded attachments are saved to the local `uploads/` folder. Attachments are optional.
- Enquiry metadata is saved to `orbit_leads.db`.
- Admin dashboard lets you view enquiries, download any submitted attachments, and update status.
- After a successful upload, it opens WhatsApp with a summary/reference (browser popup handling improved). The client must press Send in WhatsApp; the website cannot send a WhatsApp message automatically without an authorized WhatsApp Business API integration.
- Contact details remain:
  WhatsApp: +91 8200451167
  Email: s8200451167@gmail.com

RUN ON WINDOWS
1. Extract this ZIP into a normal folder, e.g. Documents\OrbitStudio.
2. Install Python 3.10+ if it is not installed. During setup, enable "Add Python to PATH".
3. Open the extracted folder in File Explorer.
4. Click the folder address bar, type `cmd`, and press Enter.
5. Run:
       py -m venv .venv
       .venv\Scripts\activate
       py -m pip install -r requirements.txt
       py app.py
6. Open http://127.0.0.1:5000 in Chrome.
7. Submit a test video under 200 MB.
8. Open http://127.0.0.1:5000/admin
   Default local admin login:
       Username: admin
       Password: ChangeThisPassword123!
9. Change the admin credentials before any public deployment (see below).

CHANGE ADMIN PASSWORD (IMPORTANT)
In Windows Command Prompt, stop the server with Ctrl+C, then run these commands before starting it again:
    set ORBIT_ADMIN_USERNAME=your_private_admin_name
    set ORBIT_ADMIN_PASSWORD=use-a-long-unique-password
    py app.py
These environment variables apply to that Command Prompt session. Never share the admin password with clients. The default is only for local testing and is unsafe for a public website.

WHERE FILES ARE SAVED
- Video files: `uploads\`
- Client enquiries database: `orbit_leads.db`
Back up both folders/file. Deleting them will delete stored videos/enquiry records.

IMPORTANT ABOUT PUBLIC CLIENT UPLOADS
This version works on your own computer for testing. If you only run it at 127.0.0.1, remote clients cannot reach it.
To accept uploads from real clients online, deploy this Flask app to a server that supports Python and persistent disk/storage. Configure:
- HTTPS
- A strong private admin username/password
- Persistent storage with enough capacity and backups
- Server/proxy upload limit at least 202 MB
- A production WSGI server (not Flask's development server)
- Privacy/retention terms and permission to upload content
Do not deploy the default admin password. Do not use ephemeral server storage for client videos because files can disappear on redeploy/restart.
The public website itself is not automatically published by this ZIP; it must be hosted/deployed.

LIMITATIONS / SAFETY
- Maximum upload size: 200 MB. Larger files should be compressed or use a larger-file transfer service.
- Accepted extensions: MP4, MOV, WEBM, MKV. Extension validation is not a full malware scan; only accept files you intend to process and keep the server updated.
- PhonePe/Paytm UPI payment instructions are included with QR + UPI ID display, transaction ID capture and manual verification. This does not verify payments automatically.
- Do not upload/share videos without the owner's permission.

PORTFOLIO SHOWCASE
- The website now includes filterable sample concepts for reels/short edits, social media designs, and website concepts.
- These are visual demo concepts, not actual completed client projects or playable video files. Replace/add your own real work as you create it.


PORTFOLIO UPDATE
- Added an "Our Work" portfolio section with sample concept cards for reels, social media designs, websites and branding.
- These are illustrative sample concepts, not claims of real completed client projects. Replace with genuine work samples when available.
- Attachments are optional so a website-design client can submit only their brief.
- Accepted file extensions include video, images, PDF, Office documents, audio, ZIP/RAR and design references.


PHONEPE / PAYTM UPI SETUP (MANUAL VERIFICATION)
1. In your PhonePe or Paytm app, open your UPI/profile section and copy your exact UPI ID. Never guess this value.
2. Put your real UPI ID in the environment variable ORBIT_UPI_ID before starting the app. Example in Windows CMD:
       set ORBIT_UPI_ID=your-real-upi-id@bank
       py app.py
   Replace the example with your own exact UPI ID.
3. Save your official UPI QR image as: static\upi-qr.png (PNG format). The website will show it automatically. If no image exists, it displays setup instructions instead.
4. When a client submits an enquiry, the transaction ID (if provided) appears in /admin. Open PhonePe/Paytm yourself and verify the amount, date and transaction before confirming the order. A screenshot or entered ID alone is not proof of payment.
5. Admin status is currently project progress only; it does not represent verified payment status. Do not mark a project confirmed until you manually verify payment.
6. Do not put UPI PINs, OTPs, passwords or banking credentials on the website.
