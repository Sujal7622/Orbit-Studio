import os
import re
import sqlite3
import secrets
from datetime import datetime
from functools import wraps
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_from_directory, Response, abort
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
UPLOAD_DIR = BASE_DIR / "uploads"
DB_PATH = BASE_DIR / "orbit_leads.db"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 10 * 200 * 1024 * 1024 + 5 * 1024 * 1024
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
ALLOWED_EXTENSIONS = {"mp4","mov","webm","mkv","jpg","jpeg","png","webp","gif","pdf","doc","docx","ppt","pptx","xls","xlsx","txt","zip","rar","mp3","wav","aac","m4a","psd","ai","fig","svg"}
WHATSAPP_NUMBER = "918200451167"
CONTACT_EMAIL = "s8200451167@gmail.com"
# User-provided PhonePe UPI ID; can be overridden with ORBIT_UPI_ID on deployment.
UPI_ID = os.environ.get("ORBIT_UPI_ID", "8200451167-y59e@ibl")
UPI_QR_PATH = BASE_DIR / "static" / "upi-qr.png"

# Set these environment variables before public deployment.
ADMIN_USERNAME = os.environ.get("ORBIT_ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.environ.get("ORBIT_ADMIN_PASSWORD", "ChangeThisPassword123!")
ADMIN_PASSWORD_HASH = os.environ.get("ORBIT_ADMIN_PASSWORD_HASH", "")


def db_connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db_connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS leads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reference TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                name TEXT NOT NULL,
                business TEXT,
                service TEXT NOT NULL,
                budget TEXT,
                details TEXT,
                package TEXT NOT NULL DEFAULT 'Not selected',
                phone TEXT NOT NULL DEFAULT '',
                transaction_id TEXT NOT NULL DEFAULT '',
                original_filename TEXT NOT NULL DEFAULT '',
                stored_filename TEXT NOT NULL DEFAULT '',
                file_size INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'New'
            )
        """)
        # Migrate existing local databases safely when this version is started again.
        columns = {row[1] for row in con.execute("PRAGMA table_info(leads)").fetchall()}
        for column, definition in [("package", "TEXT NOT NULL DEFAULT 'Not selected'"),
                                  ("phone", "TEXT NOT NULL DEFAULT ''"),
                                  ("transaction_id", "TEXT NOT NULL DEFAULT ''")]:
            if column not in columns:
                con.execute(f"ALTER TABLE leads ADD COLUMN {column} {definition}")
        # Separate attachment table supports zero, one, or many files per enquiry.
        con.execute("""
            CREATE TABLE IF NOT EXISTS attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                reference TEXT NOT NULL,
                original_filename TEXT NOT NULL,
                stored_filename TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                FOREIGN KEY(reference) REFERENCES leads(reference)
            )
        """)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def clean_text(value, limit=1000):
    return re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", (value or "").strip())[:limit]


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        auth = request.authorization
        valid_password = check_password_hash(ADMIN_PASSWORD_HASH, auth.password) if ADMIN_PASSWORD_HASH else (
            secrets.compare_digest(auth.password, ADMIN_PASSWORD) if auth and auth.password else False
        )
        if not auth or not secrets.compare_digest(auth.username, ADMIN_USERNAME) or not valid_password:
            return Response(
                "Admin login required. Set ORBIT_ADMIN_USERNAME and ORBIT_ADMIN_PASSWORD before deployment.",
                401,
                {"WWW-Authenticate": 'Basic realm="Orbit Studio Admin"'}
            )
        return view(*args, **kwargs)
    return wrapped


@app.route("/")
def home():
    return render_template("index.html", upi_id=UPI_ID, qr_available=UPI_QR_PATH.exists())


@app.route("/health")
def health():
    return jsonify({"ok": True, "service": "Orbit Studio upload server"})


@app.route("/upload", methods=["POST"])
def upload():
    name = clean_text(request.form.get("name"), 80)
    business = clean_text(request.form.get("business"), 100)
    service = clean_text(request.form.get("service"), 100)
    budget = clean_text(request.form.get("budget"), 50)
    details = clean_text(request.form.get("details"), 1000)
    package = clean_text(request.form.get("package"), 120) or "Not selected"
    phone = clean_text(request.form.get("phone"), 30)
    transaction_id = clean_text(request.form.get("transaction_id"), 100)
    files = [f for f in request.files.getlist("files") if f and f.filename]

    if not name:
        return jsonify(ok=False, error="Please enter your name."), 400
    if not service:
        return jsonify(ok=False, error="Please choose the service you need."), 400
    if len(files) > 10:
        return jsonify(ok=False, error="Please attach no more than 10 files."), 400

    safe_files = []
    for uploaded in files:
        if not allowed_file(uploaded.filename):
            return jsonify(ok=False, error=f"Unsupported file type: {secure_filename(uploaded.filename)}"), 400
        original = secure_filename(uploaded.filename)
        if not original:
            return jsonify(ok=False, error="One file has an invalid name. Rename it and try again."), 400
        safe_files.append((uploaded, original))

    reference = "ORB-" + datetime.now().strftime("%y%m%d") + "-" + secrets.token_hex(3).upper()
    saved_paths = []
    try:
        with db_connect() as con:
            # Preserve the original leads schema; legacy single-file fields remain blank.
            con.execute("""
                INSERT INTO leads
                (reference, created_at, name, business, service, budget, details, package, phone, transaction_id,
                 original_filename, stored_filename, file_size, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', '', 0, 'New')
            """, (
                reference, datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                name, business, service, budget, details, package, phone, transaction_id
            ))

            stored_names = []
            for uploaded, original in safe_files:
                stored = reference + "_" + secrets.token_hex(3) + "_" + original
                destination = UPLOAD_DIR / stored
                uploaded.save(destination)
                size = destination.stat().st_size
                if size == 0:
                    destination.unlink(missing_ok=True)
                    raise ValueError(f"{original} is empty.")
                saved_paths.append(destination)
                con.execute("""
                    INSERT INTO attachments (reference, original_filename, stored_filename, file_size)
                    VALUES (?, ?, ?, ?)
                """, (reference, original, stored, size))
                stored_names.append(original)
    except ValueError as exc:
        for path in saved_paths:
            path.unlink(missing_ok=True)
        with db_connect() as con:
            con.execute("DELETE FROM attachments WHERE reference = ?", (reference,))
            con.execute("DELETE FROM leads WHERE reference = ?", (reference,))
        return jsonify(ok=False, error=str(exc)), 400
    except Exception:
        for path in saved_paths:
            path.unlink(missing_ok=True)
        with db_connect() as con:
            con.execute("DELETE FROM attachments WHERE reference = ?", (reference,))
            con.execute("DELETE FROM leads WHERE reference = ?", (reference,))
        app.logger.exception("Could not save upload")
        return jsonify(ok=False, error=f"Server could not save the enquiry. Please email {CONTACT_EMAIL}."), 500

    return jsonify(
        ok=True, reference=reference, name=name, business=business,
        service=service, budget=budget, details=details, package=package, phone=phone,
        transaction_id=transaction_id, files=stored_names, files_count=len(stored_names)
    ), 201


@app.route("/admin")
@admin_required
def admin():
    with db_connect() as con:
        leads = con.execute("SELECT * FROM leads ORDER BY id DESC").fetchall()
        attachment_rows = con.execute("SELECT * FROM attachments ORDER BY id").fetchall()
    attachments = {}
    for item in attachment_rows:
        attachments.setdefault(item["reference"], []).append(item)
    return render_template("admin.html", leads=leads, attachments=attachments)


@app.route("/admin/download/<reference>/<stored_filename>")
@admin_required
def download_attachment(reference, stored_filename):
    with db_connect() as con:
        attachment = con.execute(
            "SELECT * FROM attachments WHERE reference = ? AND stored_filename = ?",
            (reference, stored_filename)
        ).fetchone()
    if not attachment:
        abort(404)
    return send_from_directory(
        app.config["UPLOAD_FOLDER"], attachment["stored_filename"],
        as_attachment=True, download_name=attachment["original_filename"]
    )


@app.route("/admin/status/<reference>", methods=["POST"])
@admin_required
def update_status(reference):
    status = clean_text(request.form.get("status"), 30)
    if status not in {"New", "Contacted", "In progress", "Completed"}:
        abort(400)
    with db_connect() as con:
        con.execute("UPDATE leads SET status = ? WHERE reference = ?", (status, reference))
    return Response("Status updated. Return to the admin page and refresh.", 200, mimetype="text/plain")


@app.errorhandler(413)
def too_large(_error):
    return jsonify(ok=False, error="File is too large. Maximum upload size is 200 MB."), 413


@app.errorhandler(500)
def server_error(_error):
    return jsonify(ok=False, error=f"Server error. Please contact {CONTACT_EMAIL}."), 500


init_db()

if __name__ == "__main__":
    # Local development only. Use a production WSGI server for public deployment.
    app.run(host="127.0.0.1", port=5000, debug=False)
